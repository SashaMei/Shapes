
public interface Shape  {
	
	double calculateArea();
	String toString();
	String getDescription();
	boolean equals(Object obj);

}
