
public interface TwoDimensionalShapes {
	double calculatePerimeter();
	
	

}
