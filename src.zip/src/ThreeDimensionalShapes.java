
public interface ThreeDimensionalShapes {
	 double calculateVolume();
	 boolean isPartOfShape(Object o);

}
